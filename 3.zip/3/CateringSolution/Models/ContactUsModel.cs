﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CateringServices.Web.Models
{
    public class ContactUsModel
    {
        [Required(ErrorMessage = "Please enter your name")]
        public string Name { get; set; }

        /*[EmailAddress(ErrorMessage = "Please enter a valid email address")]*/
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter your phone number")]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Please enter a valid 10-digit phone number")]
        public string PhoneNumber { get; set; }

        [Required(ErrorMessage = "Please enter your date of birth")]
        [DataType(DataType.Date)]
        public DateTime? DateOfBirth { get; set; }

        [Required(ErrorMessage = "Please enter your message")]
        [StringLength(255, ErrorMessage = "The message cannot be longer than 255 characters")]
        public string Message { get; set; }
    }

}
