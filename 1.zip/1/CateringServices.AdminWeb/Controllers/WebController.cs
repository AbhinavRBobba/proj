﻿
using Classes;
using Microsoft.AspNetCore.Mvc;

namespace CateringServices.AdminWeb.Controllers
{
    public class WebController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
